// JavaScript Document 
 function changeRowBgColor(obj) 
 { 
 	obj.style.backgroundColor="#ff6600"; 
 } 

 function RedoRowBgColor(obj) 
 { 
 	obj.style.backgroundColor="#6d4233"; 
 } 

