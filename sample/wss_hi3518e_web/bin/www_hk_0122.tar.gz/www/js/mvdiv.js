﻿<!--
var $ = document.getElementById;
var movElem = null;
var resizeElem = null;
var movHead = null;
var movStartX = 0;
var movStartY = 0;
var reSizeX = 0;
var reSizeY = 0;
var oX = 0;
var oY = 0;
var isResize = 0; //0:无 1:横 2:竖 3:斜
var isStartResize = false;

String.prototype.pix2Num = function(){
return parseInt(this.substring(0,this.length-2),10);
}

function mvdiv_init(){
//初始化弹出窗口的位置
	var oDialog=document.getElementById("divMove");
	var sClientWidth=document.body.clientWidth;
	var sClientHeight=document.body.clientHeight;
	//var sScrollTop=document.body.scrollTop;
	var sleft=(sClientWidth/2)-(450/2);
	//var iTop=-80+(sClientHeight/2+sScrollTop)-(oDialog.style.height/2);
	//var sTop=iTop>0?iTop:(sClientHeight/2+sScrollTop)-(oDialog.style.height/2);
	//if(sTop<1)sTop="20";if(sleft<1)sleft="20";
	oDialog.style.left=sleft+"px"; //左侧位置
	//oDialog.style.top=sTop+"px"     //顶部位置
	oDialog.style.top="20%";


	document.onmousedown = function(){
		if(event.srcElement.id == "divHead"){
			movElem = $("divMove");
			movElem.attachEvent("onstartselect",function(){return false;});
			movElem.attachEvent("oncontextmenu",function(){return false;});
			movHead = $("divHead");
			movHead.style.cursor = "move";
			movStartX = event.x;
			movStartY = event.y;
			oX = movElem.offsetLeft;
			oY = movElem.offsetTop;
			return;
		}

		if(isResize){
			resizeElem = event.srcElement;
			oX = resizeElem.offsetWidth;
			oY = resizeElem.offsetHeight;
			reSizeX = event.x;
			reSizeY = event.y;
			isStartResize = true;
			return;
		}
	}

	document.onmousemove = function(){
		if(movElem){
			movElem.style.left = oX + event.x - movStartX;
			movElem.style.top = oY + event.y - movStartY;
			return;
		}

		if(isStartResize){
			var x = oX +  event.x - reSizeX;
			var y = oY + event.y - reSizeY;
			x = x>0?x:0;
			y = y>0?y:0;
		switch(isResize){
			case 1:
//			resizeElem.style.width = x; break;
			case 2:
//			resizeElem.style.height = y; break;
			case 3:
//			resizeElem.style.width = x; 
//			resizeElem.style.height = y; break;
			default: break;
		}
		return;
		}

		if(event.srcElement.id == "divMove"){
			var div = $("divMove");
			//div.attachEvent("onmouseout",function(){div.style.cursor = "default";});
			var dx = Math.abs(event.x - div.offsetLeft - div.offsetWidth);
			var dy = Math.abs(event.y - div.offsetTop - div.offsetHeight);
			if( dx < 4 && dy < 4){
				isResize = 3;
//				div.style.cursor = "NW-resize";
			}else if(dx < 4){
				isResize = 1;
//				div.style.cursor = "W-resize";
			}else if(dy < 4){
				isResize = 2;
//				div.style.cursor = "N-resize";
			}else{
				if(isResize>0){
					div.style.cursor = "default";
					isResize = 0;
				}
			}

			return;
		}
	}

	document.onmouseup = function(){
		if(movElem){ 
			if(movElem.style.left.pix2Num() < 0)
				movElem.style.left = 0;
			if(movElem.style.top.pix2Num() < 0)
				movElem.style.top = 0;
			movHead.style.cursor = "default";
			movElem = null;
			return;
		}

		if(isStartResize){
		resizeElem = null;
		isResize = 0 ;
		isStartResize = false;
		return;
		}

	}
}
//-->