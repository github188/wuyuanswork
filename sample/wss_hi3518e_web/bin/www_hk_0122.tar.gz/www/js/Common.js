﻿// JavaScript Document
function changeRowBgColor(obj) 
{ 
	obj.style.background="#ff6600"; 
} 
function RedoRowBgColor(obj) 
{
	obj.style.background="#6d4233"; 
} 
function JumpToPage(Path)
{
	self.parent.document.getElementById("ifrConfigItem").src=Path;
}

 